import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_widgets.dart';
import 'tabs/home_tab.dart';
import 'tabs/profile_tab.dart';
import 'tabs/settings_tab.dart';

class MainDashboard extends StatefulWidget {
  const MainDashboard({super.key});

  @override
  State<MainDashboard> createState() => _DashState();
}

class _DashState extends State<MainDashboard> {
  var _tb = 0;

  static const _lbls = ['Dashboard', 'Profile', 'Settings'];
  static const _pgs = <Widget>[HomeTab(), ProfileTab(), SettingsTab()];

  void _tap(int i) {
    if (i == _tb) return;
    setState(() => _tb = i);
  }

  void _nav(int i) {
    Navigator.pop(context);
    _tap(i);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_lbls[_tb]),
        leading: Builder(builder: (c) => IconButton(
          icon: const Icon(Icons.menu), onPressed: () => Scaffold.of(c).openDrawer())),
      ),
      drawer: _drw(),
      body: IndexedStack(index: _tb, children: _pgs),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tb, onTap: _tap,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  Drawer _drw() {
    return Drawer(
      backgroundColor: AppColors.bg,
      child: ListView(padding: EdgeInsets.zero, children: [
        DrawerHeader(
          decoration: const BoxDecoration(color: AppColors.primary),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end,
            children: [
              const UserProfileAvatar(name: 'Munis', sz: 56),
              const SizedBox(height: 12),
              Text('Munis', style: AppTypography.sub.copyWith(color: Colors.white)),
              Text('munis@example.com', style: AppTypography.cap.copyWith(color: Colors.white70)),
            ],
          ),
        ),
        ListTile(leading: const Icon(Icons.home), title: const Text('Home'), onTap: () => _nav(0)),
        ListTile(leading: const Icon(Icons.person), title: const Text('Profile'), onTap: () => _nav(1)),
        ListTile(leading: const Icon(Icons.settings), title: const Text('Settings'), onTap: () => _nav(2)),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: AppColors.err),
          title: const Text('Logout', style: TextStyle(color: AppColors.err)),
          onTap: () => Navigator.pushReplacementNamed(context, '/login'),
        ),
      ]),
    );
  }
}
