# Pulse

A health companion mobile app built with Flutter for the WeIntern Pvt Ltd internship (Week 1).

## Setup

```bash
flutter pub get
flutter run -d chrome
```

## Structure

```
lib/
├── main.dart
├── theme/
│   └── app_theme.dart
├── widgets/
│   ├── app_buttons.dart
│   ├── app_cards.dart
│   ├── app_inputs.dart
│   ├── app_lists.dart
│   └── custom_widgets.dart
└── features/
    ├── splash/
    │   └── splash_screen.dart
    ├── auth/
    │   └── login_screen.dart
    └── home/
        ├── main_dashboard.dart
        └── tabs/
            ├── home_tab.dart
            ├── profile_tab.dart
            └── settings_tab.dart
```
